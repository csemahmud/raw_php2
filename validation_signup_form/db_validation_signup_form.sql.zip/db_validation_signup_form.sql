-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2015 at 03:23 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_validation_signup_form`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `user_id` int(6) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) NOT NULL,
  `middle_name` varchar(25) DEFAULT NULL,
  `last_name` varchar(25) NOT NULL,
  `nick_name` varchar(4) DEFAULT NULL,
  `reg_no` varchar(20) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(32) NOT NULL,
  `mobile_no` varchar(15) DEFAULT NULL,
  `address` text NOT NULL,
  `city` varchar(50) NOT NULL,
  `company_name` varchar(100) DEFAULT NULL,
  `zip_code` varchar(5) NOT NULL,
  `country` varchar(50) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `age` int(3) NOT NULL,
  `reg_date` date NOT NULL,
  `color_code` varchar(100) DEFAULT NULL,
  `browser` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `first_name`, `middle_name`, `last_name`, `nick_name`, `reg_no`, `email`, `password`, `mobile_no`, `address`, `city`, `company_name`, `zip_code`, `country`, `gender`, `age`, `reg_date`, `color_code`, `browser`) VALUES
(2, 'Mahmudul', '', 'Khan', '', '', 'cse.mahmud@yahoo.com', 'a8f5f167f44f4964e6c998dee827110c', '', 'asd', 'asd', '', '12345', 'AT', 'male', 19, '2014-04-23', '#000000', ''),
(3, 'Wonder', 'Fool', 'Woman', 'Lisa', '', 'wfwoman@mail.com', 'a8f5f167f44f4964e6c998dee827110c', '0123456789', 'New-York', 'New-York', 'DC', '12345', 'US', 'female', 18, '2014-04-14', '#8080c0', 'Firefox'),
(7, 'Super;', '', 'Man;', '', '', 'asd@asd.com', '7815696ecbf1c96e6894b779456d330e', '', 'asd', 'asd', '', 'asd', 'AS', 'male', -10, '2014-11-04', '#000000', 'Firefox'),
(8, 'asd123', '', 'asd123', '', '', 'asd@mail.com', '7815696ecbf1c96e6894b779456d330e', '', 'asd', 'asd', '', 'asd', 'AG', 'male', -8, '2014-11-04', '#000000', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
